import React from "react";
import { ConnectButton } from "@rainbow-me/rainbowkit";

export default function App() {
  return (
    <div style={{ textAlign: "center", paddingTop: "100px" }}>
      <h1>🚀 Token Sale DApp</h1>
      <ConnectButton />
    </div>
  );
}
